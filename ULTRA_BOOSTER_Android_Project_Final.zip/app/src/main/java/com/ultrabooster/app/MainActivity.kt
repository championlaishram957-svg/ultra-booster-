package com.ultrabooster.app

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Background = Color(0xFF06111F)
private val SurfaceBlue = Color(0xFF10243A)
private val SurfaceBlue2 = Color(0xFF15314E)
private val Neon = Color(0xFF55D7FF)
private val Electric = Color(0xFF398BFF)
private val Muted = Color(0xFF9CB6CC)

data class DeviceSnapshot(
    val freeRamMb: Long,
    val batteryPercent: Int,
    val batteryTempC: Float?,
    val charging: Boolean,
    val thermalLabel: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UltraBoosterApp(this) }
    }
}

@Composable
private fun UltraBoosterApp(context: Context) {
    var snapshot by remember { mutableStateOf(readSnapshot(context)) }
    var lastUpdated by remember { mutableStateOf("Live device check") }

    val temperature = snapshot.batteryTempC
    val coolingAdvice = when {
        temperature != null && temperature >= 42f ->
            "Your battery is hot. Pause gaming, unplug the charger and let the phone rest in a cool, shaded place."
        temperature != null && temperature >= 38f ->
            "Your phone is warming up. Lower graphics, reduce screen brightness and take a short break."
        snapshot.thermalLabel == "Severe" || snapshot.thermalLabel == "Critical" ||
            snapshot.thermalLabel == "Emergency" ->
            "Android reports high device heat. Stop demanding tasks and let the phone cool down."
        snapshot.charging ->
            "Charging while gaming can add heat. If possible, pause charging during intensive play."
        else ->
            "No strong heat warning detected. Keep vents clear, avoid direct sunlight and take breaks during long sessions."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Neon,
        secondary = Electric,
        background = Background,
        surface = SurfaceBlue
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF102F53), Background, Color(0xFF050C16)))
            )
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).background(
                            Brush.linearGradient(listOf(Neon, Electric)), RoundedCornerShape(15.dp)
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = Background, modifier = Modifier.size(29.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ULTRA BOOSTER", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                        Text("SMART GAMING COMPANION", color = Neon, fontSize = 9.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF123B50), shape = CircleShape) {
                        Text("FREE", color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
                    }
                }

                Spacer(Modifier.height(24.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xCC102D4A)),
                    shape = RoundedCornerShape(26.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("GAMING STATUS", color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp)
                                Spacer(Modifier.height(5.dp))
                                Text(if (snapshot.thermalLabel in listOf("Severe", "Critical", "Emergency")) "COOL DOWN" else "READY TO PLAY",
                                    color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Box(
                                Modifier.size(60.dp).background(Color(0xFF123F5A), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Gamepad, contentDescription = null, tint = Neon, modifier = Modifier.size(32.dp))
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("A smarter view of your phone's gaming conditions.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(17.dp))
                        Button(
                            onClick = {
                                snapshot = readSnapshot(context)
                                lastUpdated = "Updated just now"
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Electric)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("SCAN MY PHONE", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(lastUpdated, color = Muted, fontSize = 10.sp)
                    }
                }

                Spacer(Modifier.height(18.dp))
                Text("DEVICE INSIGHTS", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard(
                        "BATTERY", "${snapshot.batteryPercent}%",
                        if (snapshot.charging) "Charging" else "Not charging",
                        Icons.Default.BatteryChargingFull, Modifier.weight(1f)
                    )
                    MetricCard(
                        "BATTERY TEMP", temperature?.let { String.format(Locale.getDefault(), "%.1f°C", it) } ?: "N/A",
                        "Device sensor", Icons.Default.DeviceThermostat, Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))
                MetricCard(
                    "AVAILABLE MEMORY", "${snapshot.freeRamMb} MB",
                    "Android system estimate", Icons.Default.Memory, Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(18.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceBlue2),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DeviceThermostat, contentDescription = null, tint = Neon)
                            Spacer(Modifier.width(9.dp))
                            Text("SMART COOLING ASSISTANT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Thermal status: ${snapshot.thermalLabel}", color = Neon, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text(coolingAdvice, color = Color(0xFFD3E3F1), fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }

                Spacer(Modifier.height(14.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceBlue),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TipsAndUpdates, contentDescription = null, tint = Neon)
                            Spacer(Modifier.width(9.dp))
                            Text("QUICK GAME TIPS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Tip("Lower graphics or frame rate if the phone gets hot.")
                        Tip("Avoid playing in direct sunlight or under a pillow.")
                        Tip("Close games normally before opening another demanding app.")
                        Tip("Use a ventilated surface; never put your phone in a fridge or freezer.")
                    }
                }

                Spacer(Modifier.height(14.dp))
                OutlinedButton(
                    onClick = {
                        try {
                            context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {
                            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Neon),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF287EB7)),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("OPEN BATTERY & POWER SETTINGS")
                }
                Spacer(Modifier.height(20.dp))
                Text("NO ADS  •  NO SUBSCRIPTIONS  •  NO IN-APP PURCHASES",
                    color = Neon, fontSize = 9.sp, letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(6.dp))
                Text("Honest tools only: no fake FPS, RAM-cleaning or temperature claims.",
                    color = Muted, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = SurfaceBlue),
        shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = Neon, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(7.dp))
                Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(11.dp))
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun Tip(text: String) {
    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text("✦", color = Neon, fontSize = 13.sp)
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color(0xFFD3E3F1), fontSize = 12.sp, lineHeight = 17.sp)
    }
}

private fun readSnapshot(context: Context): DeviceSnapshot {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memory = ActivityManager.MemoryInfo()
    am.getMemoryInfo(memory)

    val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
    val tempRaw = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
    val temp = if (tempRaw > 0) tempRaw / 10f else null
    val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0

    val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown risk"
            else -> "Unavailable"
        }
    } else "Not supported on this Android version"

    return DeviceSnapshot(
        freeRamMb = memory.availMem / (1024 * 1024),
        batteryPercent = percent,
        batteryTempC = temp,
        charging = plugged != 0,
        thermalLabel = thermal
    )
}
