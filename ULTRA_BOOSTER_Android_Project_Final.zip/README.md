# ULTRA BOOSTER — Android project

A free Android gaming companion with a blue futuristic dashboard, built with Kotlin and Jetpack Compose.

## Included
- Gaming dashboard and manual device scan.
- Available-memory estimate from Android.
- Battery percentage and charging state.
- Battery temperature when the device exposes it.
- Android thermal status on supported Android versions.
- Cooling suggestions based on available device readings.
- Shortcut to Android battery-saver settings.
- Simple blue lightning launcher icon.
- No ads, analytics, subscriptions, or in-app purchases.

## Build an installable APK
1. Install the latest Android Studio on a computer.
2. Open this project folder (`UltraBooster`) in Android Studio.
3. Allow Gradle sync to complete. Use JDK 17.
4. Install Android SDK Platform 36 when Android Studio prompts you.
5. Connect your Android phone with USB debugging enabled, or start an emulator.
6. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. After the build completes, use the notification's **locate** link. The debug APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
8. Transfer the APK to your phone and install it. You may need to allow installation from that file manager.

## Release / Play Store
For a Play Store release, create a signed Android App Bundle using **Build > Generate Signed Bundle / APK > Android App Bundle**. Keep the signing key private and backed up. Complete Play Console's current account verification, testing, privacy, and policy steps before submitting.

## Important limitations
This app is a monitoring and advice utility, not a physical cooler. It cannot lower device temperature directly, overclock hardware, override thermal throttling, force-stop other apps, or guarantee higher FPS/lower ping. Battery temperature and thermal-status readings vary by phone. The memory figure is a system estimate; scanning does not claim to free RAM.

## Project details
- Application ID: `com.ultrabooster.app`
- Version: `1.0` (versionCode 1)
- Minimum Android: Android 6.0 (API 23)
- Compile/target SDK: 36
